# -*- coding: utf-8 -*-

from . import whatsapp_sale
from . import whatsapp_purchase
from . import whatsapp_crm
from . import whatsapp_invoice
from . import whatsapp_payment
from . import whatsapp_delivery
from . import whatsapp_partner
