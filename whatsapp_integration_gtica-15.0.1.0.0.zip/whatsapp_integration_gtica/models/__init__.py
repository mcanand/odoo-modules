# -*- coding: utf-8 -*-

from . import models
from . import whatsapp_template
from . import whatsapp_product_pricelist